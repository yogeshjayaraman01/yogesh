# TechKart – Smart Shopping. Better Decisions.
INFYHACKATHON 2.0. React/Vite/TS frontend, Express/TS/Prisma/PostgreSQL backend, JWT auth, Gemini-assisted INFY AI grounded in DB products.

## Setup
1. `cp .env.example backend/.env` and fill `DATABASE_URL`, `JWT_SECRET`, `SEED_PASSWORD`, optional `GEMINI_API_KEY`.
2. Backend: `cd backend && npm i && npx prisma migrate dev --name init && npm run seed && npm run dev`
3. Frontend: `cd frontend && npm i && npm run dev` (proxies /api to :4000)

Demo accounts: `admin@techkart.local`, `user@techkart.local` – password = your `SEED_PASSWORD`.

INFY works without Gemini (rule-based parsing + DB query); the key only polishes explanations. Production: set strong JWT_SECRET, `CLIENT_URL`, run `npx prisma migrate deploy`, `npm run build`.
