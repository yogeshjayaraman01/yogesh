import axios from 'axios';
export const api = axios.create({ baseURL: '/api' });
api.interceptors.request.use(c => { const t = localStorage.getItem('token'); if (t) c.headers.Authorization = `Bearer ${t}`; return c; });
export const errMsg = (e: any): string => e?.response?.data?.error ?? 'Something went wrong';
