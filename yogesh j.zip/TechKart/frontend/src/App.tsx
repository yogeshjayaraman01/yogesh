import { useEffect, useState } from 'react';
import { Link, Route, Routes, useNavigate } from 'react-router-dom';
import { api, errMsg } from './api';

type P = { id: number; name: string; brand: string; price: number; discount: number; stock: number; rating: number; images: { url: string }[] };
const fin = (p: P) => Math.round(p.price * (100 - p.discount) / 100);

function Products() {
  const [list, setList] = useState<P[] | null>(null); const [q, setQ] = useState(''); const [sort, setSort] = useState(''); const [cat, setCat] = useState('');
  const [msg, setMsg] = useState(''); const [ai, setAi] = useState<any>(null); const [busy, setBusy] = useState(false);
  useEffect(() => { setList(null); api.get('/products', { params: { q, sort, category: cat } }).then(r => setList(r.data)).catch(e => setMsg(errMsg(e))); }, [q, sort, cat]);
  const add = (id: number) => api.post('/cart', { productId: id, quantity: 1 }).then(() => setMsg('Added to cart')).catch(e => setMsg(errMsg(e)));
  const ask = async () => { setBusy(true); try { setAi((await api.post('/infy/recommend', { query: q })).data); } catch (e) { setMsg(errMsg(e)); } setBusy(false); };
  return <>
    <h1>Find the right technology. Smarter with INFY.</h1>
    <div className="row"><input style={{ flex: 1 }} placeholder="Search products or tell INFY what you need..." value={q} onChange={e => setQ(e.target.value)} />
      <button onClick={ask} disabled={busy || q.length < 3}>{busy ? 'Thinking…' : 'Ask INFY'}</button>
      <select value={cat} onChange={e => setCat(e.target.value)}><option value="">All</option>{['Laptops', 'Smartphones', 'Gaming', 'Accessories'].map(c => <option key={c}>{c}</option>)}</select>
      <select value={sort} onChange={e => setSort(e.target.value)}><option value="">Newest</option><option value="price_asc">Price ↑</option><option value="price_desc">Price ↓</option><option value="rating">Rating</option><option value="discount">Discount</option></select></div>
    {msg && <p className="err">{msg}</p>}
    {ai && <div className="card"><b>INFY:</b> {ai.count} product(s) found. {ai.explanation}{ai.recommended && <p>Recommended: <b>{ai.recommended.name}</b> – ₹{ai.recommended.finalPrice}</p>}</div>}
    {!list ? <p>Loading…</p> : !list.length ? <p>No products match.</p> : <div className="grid">{list.map(p => <div className="card" key={p.id}>
      <img src={p.images[0]?.url} alt={p.name} /><h4>{p.name}</h4><small>{p.brand} · ★{p.rating}</small>
      <p><s>₹{p.price}</s> <b>₹{fin(p)}</b> ({p.discount}% off)</p><small>{p.stock ? `${p.stock} in stock` : 'Out of stock'}</small><br />
      <button disabled={!p.stock} onClick={() => add(p.id)}>Add to cart</button></div>)}</div>}
  </>;
}
function Auth({ mode }: { mode: 'login' | 'register' }) {
  const [f, setF] = useState({ name: '', email: '', password: '' }); const [e, setE] = useState(''); const nav = useNavigate();
  const go = async () => { try { const r = await api.post(`/auth/${mode}`, f); localStorage.setItem('token', r.data.token); nav('/'); } catch (x) { setE(errMsg(x)); } };
  return <div className="card" style={{ maxWidth: 360 }}><h2>{mode}</h2>{mode === 'register' && <input placeholder="Name" onChange={x => setF({ ...f, name: x.target.value })} />}
    <p><input placeholder="Email" onChange={x => setF({ ...f, email: x.target.value })} /></p><p><input type="password" placeholder="Password" onChange={x => setF({ ...f, password: x.target.value })} /></p>
    <button onClick={go}>{mode}</button><p className="err">{e}</p></div>;
}
function Cart() {
  const [cart, setCart] = useState<any>(null); const [addr, setAddr] = useState(''); const [pay, setPay] = useState('UPI'); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  const load = () => api.get('/cart').then(r => setCart(r.data)).catch(e => setMsg(errMsg(e)));
  useEffect(() => { load(); }, []);
  const total = cart?.items.reduce((s: number, i: any) => s + fin(i.product) * i.quantity, 0) ?? 0;
  const upd = (id: number, quantity: number) => api.put(`/cart/${id}`, { quantity }).then(load).catch(e => setMsg(errMsg(e)));
  const checkout = async () => { setBusy(true); try { const r = await api.post('/orders', { address: addr, paymentMethod: pay }, { headers: { 'Idempotency-Key': crypto.randomUUID() } }); setMsg(`Order #${r.data.id} confirmed – ₹${r.data.total}`); load(); } catch (e) { setMsg(errMsg(e)); } setBusy(false); };
  if (!cart) return <p>{msg || 'Loading…'}</p>;
  return <><h2>Cart</h2>{msg && <p className="err">{msg}</p>}{!cart.items.length ? <p>Cart is empty.</p> : <>
    {cart.items.map((i: any) => <div className="card row" key={i.id}><b style={{ flex: 1 }}>{i.product.name}</b>₹{fin(i.product)} ×
      <input type="number" min={1} max={i.product.stock} value={i.quantity} style={{ width: 60 }} onChange={e => upd(i.id, +e.target.value)} /><button onClick={() => api.delete(`/cart/${i.id}`).then(load)}>Remove</button></div>)}
    <h3>Total ₹{total}</h3><textarea placeholder="Delivery address" value={addr} onChange={e => setAddr(e.target.value)} />
    <div className="row"><select value={pay} onChange={e => setPay(e.target.value)}><option>UPI</option><option value="CARD">Card</option><option value="COD">Cash on Delivery</option></select>
      <button disabled={busy || addr.length < 10} onClick={checkout}>Pay (simulated)</button></div></>}</>;
}
function Orders() {
  const [o, setO] = useState<any[]>([]); useEffect(() => { api.get('/orders').then(r => setO(r.data)); }, []);
  const steps = ['PENDING', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED'];
  return <><h2>Orders</h2>{o.map(x => <div className="card" key={x.id}><b>#{x.id}</b> ₹{x.total}<br />{steps.map((s, i) => <span key={s} style={{ opacity: i <= steps.indexOf(x.status) ? 1 : .3 }}>{s}{i < 4 ? ' → ' : ''}</span>)}</div>)}</>;
}
export default function App() {
  return <><nav><b>TechKart</b><Link to="/">Shop</Link><Link to="/cart">Cart</Link><Link to="/orders">Orders</Link><Link to="/login">Login</Link><Link to="/register">Register</Link></nav>
    <main><Routes><Route path="/" element={<Products />} /><Route path="/login" element={<Auth mode="login" />} /><Route path="/register" element={<Auth mode="register" />} /><Route path="/cart" element={<Cart />} /><Route path="/orders" element={<Orders />} /></Routes></main></>;
}
