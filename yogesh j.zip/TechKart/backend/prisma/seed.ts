import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
const db = new PrismaClient();
const brands = ['Lenovo', 'HP', 'ASUS', 'Dell', 'Acer', 'Samsung', 'OnePlus', 'Xiaomi', 'Logitech', 'boAt'];
type Def = { n: number; subs: string[]; base: number; step: number; specs: (i: number) => Record<string, string> };
const defs: Record<string, Def> = {
  Laptops: { n: 12, subs: ['Ultrabook', 'Gaming Laptop', 'Business'], base: 42000, step: 6500,
    specs: i => ({ CPU: ['Intel i5-12450H', 'Ryzen 5 7535HS', 'Intel i7-13620H', 'Ryzen 7 7840HS'][i % 4], RAM: i % 3 ? '16GB' : '8GB', Storage: i % 2 ? '1TB SSD' : '512GB SSD', GPU: i % 3 === 2 ? 'RTX 4050' : 'Integrated', Display: '15.6" FHD 144Hz', Battery: '56Wh' }) },
  Smartphones: { n: 10, subs: ['Android', 'Flagship', 'Budget'], base: 12000, step: 4500,
    specs: i => ({ Camera: `${48 + (i % 4) * 16}MP main`, RAM: `${6 + (i % 3) * 2}GB`, Storage: `${128 * (1 + (i % 2))}GB`, Display: '6.6" AMOLED', Battery: `${4500 + i * 100}mAh` }) },
  Gaming: { n: 8, subs: ['Consoles', 'Controllers', 'Headsets'], base: 3000, step: 4000, specs: i => ({ Type: 'Gaming', Connectivity: i % 2 ? 'Wireless' : 'Wired', Warranty: '1 year' }) },
  Accessories: { n: 10, subs: ['Audio', 'Peripherals', 'Power'], base: 600, step: 900, specs: i => ({ Connectivity: i % 2 ? 'Bluetooth' : 'USB', Warranty: '1 year', Color: ['Black', 'Grey', 'Blue'][i % 3] }) },
};
async function main() {
  const pw = process.env.SEED_PASSWORD;
  if (!pw) throw new Error('Set SEED_PASSWORD in backend/.env');
  const hash = await bcrypt.hash(pw, 10);
  for (const [email, name, role] of [['admin@techkart.local', 'Admin', 'ADMIN'], ['user@techkart.local', 'Demo User', 'CUSTOMER']] as const)
    await db.user.upsert({ where: { email }, update: {}, create: { email, name, role, password: hash } });
  if (await db.product.count()) return console.log('Products already seeded');
  for (const [cat, d] of Object.entries(defs)) {
    const c = await db.category.upsert({ where: { name: cat }, update: {}, create: { name: cat } });
    for (let i = 0; i < d.n; i++) {
      const brand = brands[(i + cat.length) % brands.length];
      const sub = d.subs[i % d.subs.length];
      await db.product.create({ data: {
        name: `${brand} ${sub} ${cat === 'Laptops' ? 'X' : 'Pro'}${100 + i * 7}`, brand, subcategory: sub, categoryId: c.id,
        description: `${brand} ${sub.toLowerCase()} in the ${cat.toLowerCase()} range.`, price: d.base + i * d.step,
        discount: [0, 5, 10, 15][i % 4], stock: 3 + ((i * 7) % 25), rating: +(3.6 + ((i * 3) % 14) / 10).toFixed(1),
        images: { create: [{ url: `https://placehold.co/600x400?text=${encodeURIComponent(brand + ' ' + cat)}` }] },
        specs: { create: Object.entries(d.specs(i)).map(([key, value]) => ({ key, value })) } } });
    }
  }
  console.log('Seeded');
}
main().finally(() => db.$disconnect());
