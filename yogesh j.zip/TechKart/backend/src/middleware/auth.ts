import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
export interface AuthReq extends Request { user?: { id: number; role: string } }
export const auth = (req: AuthReq, res: Response, next: NextFunction) => {
  try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), process.env.JWT_SECRET!) as any; next(); }
  catch { res.status(401).json({ error: 'Unauthorized' }); }
};
export const admin = (req: AuthReq, res: Response, next: NextFunction) =>
  req.user?.role === 'ADMIN' ? next() : res.status(403).json({ error: 'Forbidden' });
