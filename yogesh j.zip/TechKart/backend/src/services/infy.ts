import { db } from '../db';
const gemini = async (prompt: string): Promise<string | null> => {
  if (!process.env.GEMINI_API_KEY) return null;
  try {
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }) });
    return ((await r.json()) as any).candidates?.[0]?.content?.parts?.[0]?.text ?? null;
  } catch { return null; }
};
export const parseQuery = (q: string) => {
  const m = q.replace(/,/g, '').match(/(?:under|below|within|<|₹|rs\.?)\s*₹?\s*(\d+(?:\.\d+)?)\s*(k)?/i);
  const budget = m ? Math.round(+m[1] * (m[2] ? 1000 : 1)) : undefined;
  const ram = q.match(/(\d+)\s*gb\s*ram|ram\s*(\d+)/i);
  const l = q.toLowerCase();
  const category = /laptop/.test(l) ? 'Laptops' : /phone|camera/.test(l) ? 'Smartphones' : /gam(e|ing)|console|controller/.test(l) ? 'Gaming' : undefined;
  const useCase = /program|coding|develop/.test(l) ? 'programming' : /gaming|game/.test(l) ? 'gaming' : /student|college/.test(l) ? 'student' : /camera/.test(l) ? 'camera' : undefined;
  return { budget, ramGb: ram ? +(ram[1] || ram[2]) : undefined, category, useCase };
};
const final = (p: { price: number; discount: number }) => Math.round(p.price * (100 - p.discount) / 100);
export async function recommend(query: string) {
  const f = parseQuery(query);
  let items = await db.product.findMany({ where: { stock: { gt: 0 }, ...(f.category && { category: { name: f.category } }) }, include: { specs: true, images: true } });
  const spec = (p: any, k: string) => p.specs.find((s: any) => s.key === k)?.value ?? '';
  items = items.filter(p => (!f.budget || final(p) <= f.budget) && (!f.ramGb || parseInt(spec(p, 'RAM')) >= f.ramGb)
    && (f.useCase !== 'gaming' || f.category !== 'Laptops' || spec(p, 'GPU') !== 'Integrated'));
  const score = (p: any) => p.rating * 10 + parseInt(spec(p, 'RAM') || '0') + (f.useCase === 'camera' ? parseInt(spec(p, 'Camera')) / 8 : 0) - final(p) / 20000;
  items.sort((a, b) => score(b) - score(a));
  const top = items.slice(0, 5).map(p => ({ ...p, finalPrice: final(p) }));
  const best = top[0];
  const reasons = best ? [
    f.ramGb && `${spec(best, 'RAM')} RAM (needs ${f.ramGb}GB)`, f.budget && `₹${best.finalPrice} is within ₹${f.budget}`,
    `Rating ${best.rating}/5`, f.useCase && `Matches use case: ${f.useCase}`, spec(best, 'CPU') && `CPU: ${spec(best, 'CPU')}`].filter(Boolean) : [];
  const explanation = best ? (await gemini(`In 2 short sentences explain why ${best.name} fits "${query}". Use ONLY these facts: ${JSON.stringify(reasons)}`)) ?? reasons.join('; ') : 'No matching products in the catalogue.';
  return { filters: f, count: items.length, products: top, recommended: best ?? null, reasons, explanation };
}
export async function compare(ids: number[]) {
  const ps = await db.product.findMany({ where: { id: { in: ids.slice(0, 3) } }, include: { specs: true } });
  const rows = ps.map(p => ({ id: p.id, name: p.name, price: final(p), rating: p.rating, specs: Object.fromEntries(p.specs.map(s => [s.key, s.value])) }));
  const plain = rows.map(r => `${r.name}: ₹${r.price}, rating ${r.rating}, ${Object.entries(r.specs).map(([k, v]) => `${k} ${v}`).join(', ')}`).join('\n');
  const explanation = (await gemini(`Compare these products in simple language using ONLY this data:\n${plain}`)) ?? plain;
  return { products: rows, explanation };
}
