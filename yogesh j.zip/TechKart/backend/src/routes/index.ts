import { Router, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { db } from '../db';
import { auth, admin, AuthReq } from '../middleware/auth';
import { recommend, compare } from '../services/infy';
const r = Router();
const h = (fn: (q: AuthReq, s: Response) => Promise<any>) => (q: AuthReq, s: Response, n: NextFunction) => fn(q, s).catch(e => e instanceof z.ZodError ? s.status(400).json({ error: e.errors[0].message }) : n(e));
const clean = (s: string) => s.replace(/[<>]/g, '').trim();
const sign = (u: { id: number; role: string }) => jwt.sign({ id: u.id, role: u.role }, process.env.JWT_SECRET!, { expiresIn: '7d' });
const pub = (u: any) => ({ id: u.id, name: u.name, email: u.email, role: u.role });
const fp = (p: { price: number; discount: number }) => Math.round(p.price * (100 - p.discount) / 100);

r.post('/auth/register', h(async (q, s) => {
  const b = z.object({ name: z.string().min(2), email: z.string().email(), password: z.string().min(8) }).parse(q.body);
  if (await db.user.findUnique({ where: { email: b.email.toLowerCase() } })) return s.status(409).json({ error: 'Email already registered' });
  const u = await db.user.create({ data: { name: clean(b.name), email: b.email.toLowerCase(), password: await bcrypt.hash(b.password, 10) } });
  s.status(201).json({ token: sign(u), user: pub(u) });
}));
r.post('/auth/login', h(async (q, s) => {
  const b = z.object({ email: z.string().email(), password: z.string() }).parse(q.body);
  const u = await db.user.findUnique({ where: { email: b.email.toLowerCase() } });
  if (!u || !(await bcrypt.compare(b.password, u.password))) return s.status(401).json({ error: 'Invalid credentials' });
  s.json({ token: sign(u), user: pub(u) });
}));
r.get('/auth/me', auth, h(async (q, s) => s.json(pub(await db.user.findUnique({ where: { id: q.user!.id } })))));

r.get('/products', h(async (q, s) => {
  const { q: text, category, subcategory, brand, minPrice, maxPrice, rating, inStock, sort } = q.query as Record<string, string>;
  const where: any = { ...(text && { OR: [{ name: { contains: text, mode: 'insensitive' } }, { brand: { contains: text, mode: 'insensitive' } }] }),
    ...(category && { category: { name: category } }), ...(subcategory && { subcategory }), ...(brand && { brand }),
    ...((minPrice || maxPrice) && { price: { gte: +minPrice || 0, lte: +maxPrice || 10_000_000 } }), ...(rating && { rating: { gte: +rating } }), ...(inStock === 'true' && { stock: { gt: 0 } }) };
  const orderBy: any = ({ price_asc: { price: 'asc' }, price_desc: { price: 'desc' }, rating: { rating: 'desc' }, discount: { discount: 'desc' } } as any)[sort ?? ''] ?? { createdAt: 'desc' };
  s.json(await db.product.findMany({ where, orderBy, include: { images: true, category: true } }));
}));
r.get('/products/:id', h(async (q, s) => {
  const p = await db.product.findUnique({ where: { id: +q.params.id }, include: { images: true, specs: true, category: true, reviews: { include: { user: { select: { name: true } } } } } });
  p ? s.json(p) : s.status(404).json({ error: 'Not found' });
}));
const prodSchema = z.object({ name: z.string().min(2), brand: z.string(), description: z.string(), price: z.number().int().positive(), discount: z.number().int().min(0).max(90), stock: z.number().int().min(0),
  subcategory: z.string(), categoryId: z.number().int(), images: z.array(z.string().url()), specs: z.record(z.string()) });
const prodData = (b: z.infer<typeof prodSchema>) => ({ name: clean(b.name), brand: clean(b.brand), description: clean(b.description), price: b.price, discount: b.discount, stock: b.stock, subcategory: clean(b.subcategory), categoryId: b.categoryId });
const nested = (b: z.infer<typeof prodSchema>) => ({ images: { create: b.images.map(url => ({ url })) }, specs: { create: Object.entries(b.specs).map(([key, value]) => ({ key, value })) } });
r.post('/products', auth, admin, h(async (q, s) => { const b = prodSchema.parse(q.body); s.status(201).json(await db.product.create({ data: { ...prodData(b), ...nested(b) } })); }));
r.put('/products/:id', auth, admin, h(async (q, s) => { const b = prodSchema.parse(q.body); const id = +q.params.id;
  s.json(await db.$transaction(async t => { await t.productImage.deleteMany({ where: { productId: id } }); await t.productSpecification.deleteMany({ where: { productId: id } });
    return t.product.update({ where: { id }, data: { ...prodData(b), ...nested(b) } }); })); }));
r.delete('/products/:id', auth, admin, h(async (q, s) => { await db.product.delete({ where: { id: +q.params.id } }); s.status(204).end(); }));

const catName = z.object({ name: z.string().min(2) });
r.get('/categories', h(async (_q, s) => s.json(await db.category.findMany())));
r.post('/categories', auth, admin, h(async (q, s) => s.status(201).json(await db.category.create({ data: { name: clean(catName.parse(q.body).name) } }))));
r.put('/categories/:id', auth, admin, h(async (q, s) => s.json(await db.category.update({ where: { id: +q.params.id }, data: { name: clean(catName.parse(q.body).name) } }))));
r.delete('/categories/:id', auth, admin, h(async (q, s) => { await db.category.delete({ where: { id: +q.params.id } }); s.status(204).end(); }));

const getCart = (userId: number) => db.cart.upsert({ where: { userId }, update: {}, create: { userId }, include: { items: { include: { product: { include: { images: true } } } } } });
r.get('/cart', auth, h(async (q, s) => s.json(await getCart(q.user!.id))));
r.post('/cart', auth, h(async (q, s) => {
  const b = z.object({ productId: z.number().int(), quantity: z.number().int().min(1) }).parse(q.body);
  const p = await db.product.findUnique({ where: { id: b.productId } });
  if (!p || p.stock < 1) return s.status(400).json({ error: 'Out of stock' });
  const cart = await getCart(q.user!.id); const ex = cart.items.find(i => i.productId === b.productId);
  const quantity = Math.min((ex?.quantity ?? 0) + b.quantity, p.stock);
  await db.cartItem.upsert({ where: { cartId_productId: { cartId: cart.id, productId: b.productId } }, update: { quantity }, create: { cartId: cart.id, productId: b.productId, quantity } });
  s.json(await getCart(q.user!.id));
}));
r.put('/cart/:itemId', auth, h(async (q, s) => {
  const { quantity } = z.object({ quantity: z.number().int().min(1) }).parse(q.body);
  const it = await db.cartItem.findFirst({ where: { id: +q.params.itemId, cart: { userId: q.user!.id } }, include: { product: true } });
  if (!it) return s.status(404).json({ error: 'Not found' });
  if (quantity > it.product.stock) return s.status(400).json({ error: `Only ${it.product.stock} in stock` });
  await db.cartItem.update({ where: { id: it.id }, data: { quantity } }); s.json(await getCart(q.user!.id));
}));
r.delete('/cart/:itemId', auth, h(async (q, s) => { await db.cartItem.deleteMany({ where: { id: +q.params.itemId, cart: { userId: q.user!.id } } }); s.json(await getCart(q.user!.id)); }));

r.get('/wishlist', auth, h(async (q, s) => s.json(await db.wishlist.findMany({ where: { userId: q.user!.id }, include: { product: { include: { images: true } } } }))));
r.post('/wishlist', auth, h(async (q, s) => { const productId = z.object({ productId: z.number().int() }).parse(q.body).productId;
  s.status(201).json(await db.wishlist.upsert({ where: { userId_productId: { userId: q.user!.id, productId } }, update: {}, create: { userId: q.user!.id, productId } })); }));
r.delete('/wishlist/:productId', auth, h(async (q, s) => { await db.wishlist.deleteMany({ where: { userId: q.user!.id, productId: +q.params.productId } }); s.status(204).end(); }));

r.post('/orders', auth, h(async (q, s) => {
  const b = z.object({ address: z.string().min(10), paymentMethod: z.enum(['UPI', 'CARD', 'COD']) }).parse(q.body);
  const key = q.header('Idempotency-Key') || undefined;
  try {
    const order = await db.$transaction(async t => {
      const cart = await t.cart.findUnique({ where: { userId: q.user!.id }, include: { items: { include: { product: true } } } });
      if (!cart?.items.length) throw Object.assign(new Error('Cart is empty'), { status: 400 });
      let total = 0;
      for (const i of cart.items) {
        const ok = await t.product.updateMany({ where: { id: i.productId, stock: { gte: i.quantity } }, data: { stock: { decrement: i.quantity } } });
        if (!ok.count) throw Object.assign(new Error(`Insufficient stock: ${i.product.name}`), { status: 400 });
        total += fp(i.product) * i.quantity;
      }
      const o = await t.order.create({ data: { userId: q.user!.id, total, paymentMethod: b.paymentMethod, address: clean(b.address), idempotencyKey: key,
        items: { create: cart.items.map(i => ({ productId: i.productId, name: i.product.name, quantity: i.quantity, price: fp(i.product) })) } }, include: { items: true } });
      await t.cartItem.deleteMany({ where: { cartId: cart.id } });
      return o;
    });
    s.status(201).json(order);
  } catch (e: any) { if (e.code === 'P2002') return s.status(409).json({ error: 'Duplicate checkout' }); throw e; }
}));
r.get('/orders', auth, h(async (q, s) => s.json(await db.order.findMany({ where: { userId: q.user!.id }, include: { items: true }, orderBy: { createdAt: 'desc' } }))));
r.get('/orders/:id', auth, h(async (q, s) => { const o = await db.order.findFirst({ where: { id: +q.params.id, userId: q.user!.id }, include: { items: true } }); o ? s.json(o) : s.status(404).json({ error: 'Not found' }); }));

r.get('/products/:id/reviews', h(async (q, s) => s.json(await db.review.findMany({ where: { productId: +q.params.id }, include: { user: { select: { name: true } } } }))));
r.post('/products/:id/reviews', auth, h(async (q, s) => {
  const b = z.object({ rating: z.number().int().min(1).max(5), comment: z.string().min(3) }).parse(q.body); const productId = +q.params.id;
  await db.review.upsert({ where: { userId_productId: { userId: q.user!.id, productId } }, update: { rating: b.rating, comment: clean(b.comment) }, create: { userId: q.user!.id, productId, rating: b.rating, comment: clean(b.comment) } });
  const agg = await db.review.aggregate({ where: { productId }, _avg: { rating: true } });
  await db.product.update({ where: { id: productId }, data: { rating: +(agg._avg.rating ?? 0).toFixed(1) } }); s.status(201).json({ ok: true });
}));

r.get('/admin/dashboard', auth, admin, h(async (_q, s) => {
  const [products, users, orders, rev, low, recent, byStatus] = await Promise.all([db.product.count(), db.user.count(), db.order.count(), db.order.aggregate({ _sum: { total: true } }),
    db.product.findMany({ where: { stock: { lt: 5 } } }), db.order.findMany({ take: 5, orderBy: { createdAt: 'desc' } }), db.order.groupBy({ by: ['status'], _count: true })]);
  s.json({ products, users, orders, revenue: rev._sum.total ?? 0, lowStock: low, recentOrders: recent, byStatus });
}));
r.get('/admin/users', auth, admin, h(async (q, s) => { const t = q.query.q ? String(q.query.q) : '';
  const us = await db.user.findMany({ where: t ? { OR: [{ name: { contains: t, mode: 'insensitive' } }, { email: { contains: t, mode: 'insensitive' } }] } : {}, include: { _count: { select: { orders: true } } } });
  s.json(us.map(u => ({ ...pub(u), createdAt: u.createdAt, orderCount: u._count.orders }))); }));
r.get('/admin/orders', auth, admin, h(async (q, s) => { const t = q.query.q ? String(q.query.q) : '';
  s.json(await db.order.findMany({ where: t ? { OR: [{ id: +t || -1 }, { user: { email: { contains: t, mode: 'insensitive' } } }] } : {}, include: { items: true, user: { select: { name: true, email: true } } }, orderBy: { createdAt: 'desc' } })); }));
r.put('/admin/orders/:id/status', auth, admin, h(async (q, s) => s.json(await db.order.update({ where: { id: +q.params.id }, data: { status: z.object({ status: z.enum(['PENDING', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED']) }).parse(q.body).status } }))));

const qs = z.object({ query: z.string().min(3) });
r.post('/infy/recommend', h(async (q, s) => s.json(await recommend(qs.parse(q.body).query))));
r.post('/infy/search', h(async (q, s) => s.json(await recommend(qs.parse(q.body).query))));
r.post('/infy/compare', h(async (q, s) => s.json(await compare(z.object({ ids: z.array(z.number().int()).min(2).max(3) }).parse(q.body).ids))));
export default r;
